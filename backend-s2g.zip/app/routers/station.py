from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.schemas.station import Station, StationCreate
from app.models.station import Station as StationModel
from app.core.database import get_db

router = APIRouter(prefix="/stations", tags=["stations"])

@router.post("/", response_model=Station)
def create_station(station: StationCreate, db: Session = Depends(get_db)):
    db_station = StationModel(**station.dict())
    db.add(db_station); db.commit()
    db.refresh(db_station)
    return db_station

@router.get("/", response_model=List[Station])
def get_stations(db: Session = Depends(get_db)):
    return db.query(StationModel).all()

@router.patch("/{station_id}", response_model=Station)
def update_station_status(station_id: int, status: str, db: Session = Depends(get_db)):
    db_station = db.query(StationModel).get(station_id)
    if not db_station:
        raise HTTPException(404, "Station not found")
    db_station.status = status
    db.commit(); db.refresh(db_station)
    return db_station
