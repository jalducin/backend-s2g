from fastapi import FastAPI
from app.routers import auth, station
from app.core.scheduler import start_scheduler

app = FastAPI(title="S2G Backend API")

app.include_router(auth.router)
app.include_router(station.router)

@app.on_event("startup")
def startup_event():
    start_scheduler()