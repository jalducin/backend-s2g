# Backend - S2G Energy Challenge

## Requisitos
- Python 3.11
- Docker

## Cómo correr

```bash
docker build -t s2g-backend .
docker run -p 8000:8000 s2g-backend
```

## Endpoints
- `/auth/login` para obtener token JWT
- `/stations/` para consultar o registrar estaciones
- `/stations/{id}` con PATCH para cambiar estado